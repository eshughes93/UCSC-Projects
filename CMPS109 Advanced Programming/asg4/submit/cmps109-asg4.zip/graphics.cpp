/***************************************
 * Evan Hughes [eshughes]
 * Hadley Black [hablack]
 * cmps109 - Wesley Mackey - Spring 2014
 * assignment 4 - oop inheritance
 ***************************************/

// implementation file for window class

#include <iostream>
using namespace std;

#include <GL/freeglut.h>

#include "graphics.h"
#include "util.h"

// Initialze default window field values
int window::width = 640; // in pixels
int window::height = 480; // in pixels
int window::mb = 4;
GLfloat window::b_t = 2;
GLfloat window::sel_bt = 4;
rgbcolor window::b_c = rgbcolor(255, 0, 0);
vector<object> window::objects;
size_t window::selected_obj = 0;
mouse window::mus;

// -- object ctor -- //
object::object(const shared_ptr<shape> psh,vertex& vert,rgbcolor& rgb):
     pshape(psh), center(vert), color(rgb),select_color(window::b_c), 
                                          selected(false) {};
// Executed when window system signals to shut down.
void window::close() {
   DEBUGF ('g', sys_info::execname() << ": exit ("
           << sys_info::exit_status() << ")");
   exit (sys_info::exit_status());
}

// Executed when mouse enters or leaves window.
void window::entry (int mouse_entered) {
   DEBUGF ('g', "mouse_entered=" << mouse_entered);
   window::mus.entered = mouse_entered;
   if (window::mus.entered == GLUT_ENTERED) {
      cout << sys_info::execname() << ": width=" << window::width
           << ", height=" << window::height << endl;
   }
   glutPostRedisplay();
}

//checks center of object to wrap around window
// i.e. if the object goes over the right border,
// it will reappear on the left
void object::center_check(){
   if(center.xpos < 0) center.xpos = window::width;
   if(center.xpos > window::width) center.xpos = 0;
   if(center.ypos < 0) center.ypos = window::height;
   if(center.ypos > window::height) center.ypos = 0;
 //cout << "bordercheck " << center.xpos << " " << center.ypos << endl;
}
// Called to display the objects in the window.
void window::display() {
   glClear (GL_COLOR_BUFFER_BIT);
   glEnable(GL_LINE_SMOOTH);
   glLineWidth(window::b_t);
   select_object(window::selected_obj);
   for (auto& object: window::objects) {
      if(object.get_sel()) glLineWidth(window::sel_bt);
      else glLineWidth(window::b_t);
      object.center_check();
      //cout << selected_obj << " : " << object.get_sel() << endl;
      object.draw();
   }
   mus.draw();
   glutSwapBuffers();
}

// Called when window is opened and when resized.
void window::reshape (int width, int height) {
   DEBUGF ('g', "width=" << width << ", height=" << height);
   window::width = width;
   window::height = height;
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity();
   gluOrtho2D (0, window::width, 0, window::height);
   glMatrixMode (GL_MODELVIEW);
   glViewport (0, 0, window::width, window::height);
   glClearColor (0.25, 0.25, 0.25, 1.0);
   glutPostRedisplay();
}

// moves an object
void window::move_selected_object(GLfloat xpos, GLfloat ypos) {
   window::objects[window::selected_obj].move(xpos, ypos);
}


// Executed when a regular keyboard key is pressed.
enum {BS=8, TAB=9, ESC=27, SPACE=32, DEL=127};
void window::keyboard (GLubyte key, int x, int y) {
   DEBUGF ('g', "key=" << (unsigned)key << ", x=" << x << ", y=" << y);
   window::mus.set (x, y);
   switch (key) {
      case 'Q': case 'q': case ESC:
         window::close();
         break;
      case 'H': case 'h':
         move_selected_object (-mb, 0);
         break;
      case 'J': case 'j':
         move_selected_object (0, -mb);
         break;
      case 'K': case 'k':
         move_selected_object (0, mb);
         break;
      case 'L': case 'l':
         move_selected_object (mb, 0);
         break;
      case 'N': case 'n': case SPACE: case TAB:
         if(window::selected_obj == window::objects.size() - 1) 
                   select_object(0);
         else      select_object(window::selected_obj+1);
         break;
      case 'P': case 'p': case BS:
         if(window::selected_obj == 0) 
                   select_object(window::objects.size()-1);
         else      select_object(window::selected_obj-1);
         break;
      case '0': select_object(0); break;
      case '1': select_object(1); break;
      case '2': select_object(2); break;
      case '3': select_object(3); break;
      case '4': select_object(4); break;
      case '5': select_object(5); break;
      case '6': select_object(6); break;
      case '7': select_object(7); break;
      case '8': select_object(8); break;
      case '9': select_object(9); break;
      default:
         cerr << (unsigned)key << ": invalid keystroke" << endl;
         break;
   }
   glutPostRedisplay();
}

// Changes window's current selected object //
void window::select_object(size_t obj){
   if(obj > window::objects.size()-1) return;
   window::objects[window::selected_obj].set_selected(false);
   window::selected_obj = obj;
   window::objects[window::selected_obj].set_selected(true);
}
// Executed when a special function key is pressed.
void window::special (int key, int x, int y) {
   DEBUGF ('g', "key=" << key << ", x=" << x << ", y=" << y);
   window::mus.set (x, y);
   switch (key) {
      case GLUT_KEY_LEFT: move_selected_object (-mb, 0); break;
      case GLUT_KEY_DOWN: move_selected_object (0, -mb); break;
      case GLUT_KEY_UP: move_selected_object (0, +mb); break;
      case GLUT_KEY_RIGHT: move_selected_object (+mb, 0); break;
      case GLUT_KEY_F1: select_object(1); break;
      case GLUT_KEY_F2: select_object(2); break;
      case GLUT_KEY_F3: select_object(3); break;
      case GLUT_KEY_F4: select_object(4); break;
      case GLUT_KEY_F5: select_object(5); break;
      case GLUT_KEY_F6: select_object(6); break;
      case GLUT_KEY_F7: select_object(7); break;
      case GLUT_KEY_F8: select_object(8); break;
      case GLUT_KEY_F9: select_object(9); break;
      case GLUT_KEY_F10: select_object(10); break;
      case GLUT_KEY_F11: select_object(11); break;
      case GLUT_KEY_F12: select_object(12); break;
      default:
         cerr << (unsigned)key << ": invalid function key" << endl;
         break;
   }
   glutPostRedisplay();
}


void window::motion (int x, int y) {
   DEBUGF ('g', "x=" << x << ", y=" << y);
   window::mus.set (x, y);
   glutPostRedisplay();
}

void window::passivemotion (int x, int y) {
   DEBUGF ('g', "x=" << x << ", y=" << y);
   window::mus.set (x, y);
   glutPostRedisplay();
}

void window::mousefn (int button, int state, int x, int y) {
   DEBUGF ('g', "button=" << button << ", state=" << state
           << ", x=" << x << ", y=" << y);
   window::mus.state (button, state);
   window::mus.set (x, y);
   glutPostRedisplay();
}

void window::main () {
   static int argc = 0;
   glutInit (&argc, nullptr);
   glutInitDisplayMode (GLUT_RGBA | GLUT_DOUBLE);
   glutInitWindowSize (window::width, window::height);
   glutInitWindowPosition (128, 128);
   glutCreateWindow (sys_info::execname().c_str());
   glutCloseFunc (window::close);
   glutEntryFunc (window::entry);
   glutDisplayFunc (window::display);
   glutReshapeFunc (window::reshape);
   glutKeyboardFunc (window::keyboard);
   glutSpecialFunc (window::special);
   glutMotionFunc (window::motion);
   glutPassiveMotionFunc (window::passivemotion);
   glutMouseFunc (window::mousefn);
   DEBUGF ('g', "Calling glutMainLoop()");
   cout << "calling glutmainloop" << endl;
   glutMainLoop();
}


void mouse::state (int button, int state) {
   switch (button) {
      case GLUT_LEFT_BUTTON: left_state = state; break;
      case GLUT_MIDDLE_BUTTON: middle_state = state; break;
      case GLUT_RIGHT_BUTTON: right_state = state; break;
   }
}

void mouse::draw() {
   static rgbcolor color ("green");
   ostringstream text;
   text << "(" << xpos << "," << window::height - ypos << ")";
   if (left_state == GLUT_DOWN) text << "L"; 
   if (middle_state == GLUT_DOWN) text << "M"; 
   if (right_state == GLUT_DOWN) text << "R"; 
   if (entered == GLUT_ENTERED) {
      void* font = GLUT_BITMAP_HELVETICA_18;
      glColor3ubv (color.ubvec);
      glRasterPos2i (10, 10);
      glutBitmapString (font, (GLubyte*) text.str().c_str());
   }
}

