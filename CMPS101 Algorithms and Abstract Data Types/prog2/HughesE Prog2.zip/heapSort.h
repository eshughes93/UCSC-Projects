//Evan Hughes [eshughes@ucsc.edu]

#ifndef __HEAPSORT_H__
#define __HEAPSORT_H_

void heapSort(int keys[], int numKeys); //performs heapSort on an array of keys, user can see changes made to the passed keys[] array.

#endif
