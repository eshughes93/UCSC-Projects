//Evan Hughes [eshughes@ucsc.edu]

#ifndef __INSERTIONSORT_H__
#define __INSERTIONSORT_H_

//performs insertionSort algorithm upon a given array, user can see changes in passed array
void insertionSort(int keys[], int numKeys);

#endif
